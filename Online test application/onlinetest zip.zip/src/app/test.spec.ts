import { Component } from '@angular/core';
import {Test} from './test';

describe('Test', () => {
  it('should create an instance', () => {
    expect(Component).toBeTruthy();
  });
});
