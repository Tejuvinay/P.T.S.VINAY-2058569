export class Test {
    constructor(public question:string,public ans1:string, public ans2:string,ans3:string,ans4:string,){


        
    }
}

