class Employee{
    constructor(name,id,gender,date){
        this.name=name;
        this.id=id;
        this.gender=gender;
        this.date=date;
    }
} 

let readline=require("readline-sync")
let emp=new Employee()
let name= readline.question("Enter your name");
let id=readline.questionInt("Enter your ID")
let gender= readline.question("Enter your gender");
emp.name=name;
emp.id=id;
emp.gender=gender
emp.date=new Date()
console.log(name)
debugger;
console.log(id)
debugger;
console.log(gender)

let fs=require("fs")
let employee=JSON.parse(fs.readFileSync("logemployee.json").toString());
employee.push(emp)
let empstring=JSON.stringify(employee)
fs.writeFileSync("logemployee.json",empstring);

console.log(employee)
