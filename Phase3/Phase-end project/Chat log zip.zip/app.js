let express = require("express");
let app = express();
let bodyParser = require("body-parser");
let mongoose = require("mongoose");
let cors = require("cors");
let http = require("http").Server(app);
const { request, response } = require("express");
mongoose.pluralize(null);


let io = require('socket.io')(http);
// add middleware
app.use(cors());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static('public'));
mongoose.Promise = global.Promise;
let url = ("mongodb://localhost:27017/Chatlogs2");

var nameSchema = new mongoose.Schema({
    name: String,
    text: String
})

var message = mongoose.model("msg", nameSchema);
mongoose.connect(url).
    then(res => {
        console.log("Database conected")
    }).
    catch(error => console.log(error));

app.get("/", (request, response) => {
    response.sendFile(__dirname + "//index.html");
})
io.on("connection", (socket) => {
   
    socket.on("obj", (msg) => {
        console.log(msg);
    })
    // sending data to client 
    socket.emit("obj1", "Welcome to Chat logs");
})
app.post("/addmessage", async (request, response) => {
    try {
        var data = new message(request.body);
        await data.save()
        response.send("<html>Message saved in database" + data + "</html")
        io.emit('chat', request.body)
        console.log(data);
    } catch {
        response.sendStatus(500)
        console.log(error)
    }

})
app.get('/chat', (request, response) => {
    message.find({}, (err, chats) => {
        if (!err) {
            let display = "<html><div style=margin-top:20px><table border=2 style=color:red;text-align:center;width:60%>";
            display += "<tr><th>Name : Message</th></tr>"
            const resulthtml = chats.map(result => {
                display += "<tr>"
                display += "<td>" +""+ result.name +"--- "+ result.text+ "</td>"
            
                display += "</tr>"
            })
            display = display + "</table></div></html>"
            response.send(display)
        } else {
            response.send(err);
        }
    })
})

http.listen(9045, () => console.log("Server running on port number 9045"))