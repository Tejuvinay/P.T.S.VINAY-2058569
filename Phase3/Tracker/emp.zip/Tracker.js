let http = require("http");
let url = require("url");
let fs=require("fs")
let details=[]


let indexPage = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Welcome to Task Tracker</h2>
    <h2>Enter the details</h2>
    <form action="checkLogin">
        <label>Employee_ID</label>
        <input type="text" name="empid"/><br/>
        <label>Emp_Name..</label>
        <input type="text" name="empname"/><br/>
        <label>Task___:</label>
        <input type="text" name="task"/><br/>
        <label>Date___:</label>
        <input type="date" name="date"/><br/>
        <input type="submit" value="submit"/>
       <input type="reset" value="reset"/> <br/></br></br>
       <a href="signup">Delete employee </a><br><br>
       <a href="delete"> Display data </a><br><br>
 
       
       
    </form>
</body>
</html> 
`
let registerLoginPage=`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Delete Page</h2>
    <form action="register">
        <label>Emp_id</label>
        <input type="text" name="empid"/><br/>
        
        <input type="submit" value="Delete"/>
       <input type="reset" value="reset"/> 
       <a href="Login"><h3>Back <h3></a>
    </form>
</body>
</html>
`
let Page=`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Display Page</h2>
    <form action="display">
        <input type="submit" value="Display"/>
        <a href="Login"><h3>Back <h3></a>
       
    </form>
    
</body>
</html>
`


let server = http.createServer((request,response)=> {
    let urlInfo = url.parse(request.url,true);
  
    
        if(urlInfo.path != "/favicon.ico"){
            if(urlInfo.path == "/AboutUs"){
                    response.write("Welcome to About Us Page");
            }else if(urlInfo.path == "/ContactUs"){
                response.write("Welcome to Contact Us Page");
            }else if(urlInfo.path =="/signup"){
                response.write(registerLoginPage);}
                else if(urlInfo.path =="/delete"){
                    response.write(Page);}
            else if(urlInfo.path == "/Login"){
                response.write(indexPage);}
                else if(urlInfo.pathname=="/checkLogin"){
                    let login=urlInfo.query
                    let result = details.find(l=>l.empid == login.empid);
               
                response.writeHead(200,{"content-type":"text/html"});
                
                    if(result == undefined){
                        details.push(login);
                   
                          
                        response.write("Employee details registered")
                       console.log("data stored in a file")
                       let emp=JSON.parse(fs.readFileSync("emp.json").toString())
                       emp.push(login);
                       taskstring=JSON.stringify(emp)
                       fs.writeFileSync("emp.json",taskstring)
               
                      }else {
                        response.write("id must be unique!");     
                        response.write(indexPage); 
                }
                
                }else if(urlInfo.pathname == "/register"){
                    let login = urlInfo.query;
                    let result = details.find(l=>l.empid == login.empid);
                 
                    response.writeHead(200,{"content-type":"text/html"});
                    if(result == undefined){
                        
                        response.write("Enter correct id");
                    }else{
                        var key=result
                     
                        let emp=JSON.parse(fs.readFileSync("emp.json").toString())
                     
                        
                      
                        let empids=[];
                       emp.forEach(function(emp){
                           empids.push(emp)
                         })
                      

                         for (let index = 0; index < empids.length; index++) {
                                if(empids[index].empid==result.empid){
                                    console.log(result)
                                    empids.splice(index, 1);
                            }
                        }
                        taskstring=JSON.stringify(empids)
                        fs.writeFileSync("emp.json",taskstring)
                         response.write("Task has been Deleted")
                    }
                    }else if(urlInfo.pathname == "/display"){
                        let emp=JSON.parse(fs.readFileSync("emp.json").toString())
                    
                        taskstring=JSON.stringify(emp)
                        console.log(emp.length)

                        var tableContent=""
    var startTable ="<table border=1><tr><th>Employee_ID</th><th>Name.... </th><th>Task.....</th><th>Date.......</th></tr>"
    for(let i=0;i<emp.length;i++){
        
    tableContent +="<tr><td>"+emp[i].empid+"</td><td>"+emp[i].empname+"</td><td>"+emp[i].task+"</td><td>"+emp[i].date+"</td></tr>"
    }
    var endTable="</table>"
    tableContent = startTable+tableContent+endTable
   
     Page=tableContent;
                        response.write(tableContent)
                    }
                else {
                    response.write(indexPage);  
                }
            
    response.end();
            }
})

server.listen(1955,()=>console.log("Server running on port number 1955"))


