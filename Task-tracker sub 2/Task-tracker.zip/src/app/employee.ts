export class Employee {
  constructor(public id:string, public Name: string,public Task:string,public DeadLine:string) {

  }
}
